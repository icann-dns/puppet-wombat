#!/usr/bin/env python3
#
# Copyright 2018 Internet Corporation for Assigned Names and Numbers.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, you can obtain one at https://mozilla.org/MPL/2.0/.
#
# Developed by Sinodun IT (sinodun.com)
#
# Add a job to a Wombat queue.

import argparse
import logging
import sys

import wombat.common as wc

def main():
    parser = argparse.ArgumentParser(description='add a job to a processing queue.')
    parser.add_argument('-c', '--config',
                        dest='conf_file', action='store', default=None,
                        help='configuration file location',
                        metavar='CONFIG_FILE')
    parser.add_argument('-q', '--queue',
                        dest='queue', action='store',
                        choices=['cdns-to-tsv', 'cdns-to-pcap', 'import-tsv'],
                        required=True,
                        help='the queue to use - cdns-to-tsv, cdns-to-pcap or import-tsv',
                        metavar='QUEUE')
    parser.add_argument('jobs',
                        nargs='+',
                        help='the job string to add to the queue',
                        metavar='JOB')

    args = parser.parse_args()

    cfg = wc.getConfigOrExit(args.conf_file)

    try:
        with wc.QueueContext(cfg, parser.prog).writer() as writer:
            for job in args.jobs:
                writer.add(args.queue, job)
        sys.exit(0)
    except Exception as e:
        logging.error('exception {exc} ({args})'.format(
            exc=type(e).__name__,
            args=str(e)))
    sys.exit(1)

if __name__ == "__main__":
    main()
