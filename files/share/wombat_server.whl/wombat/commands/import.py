#!/usr/bin/env python3
#
# Copyright 2018 Internet Corporation for Assigned Names and Numbers.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, you can obtain one at https://mozilla.org/MPL/2.0/.
#
# Developed by Sinodun IT (sinodun.com)
#
# Scan Wombat incoming directories looking for new C-DNS files (.cbor.xz)
# that have not yet been added to the list for processing, and add them.

import argparse
import datetime
import fcntl
import fnmatch
import logging
import os
import os.path
import pathlib
import sys

import wombat.common as wc

DATE_TIME_FORMATS = ['%Y-%m-%d %H:%M:%S', '%Y%m%d_%H%M%S', '%Y-%m-%d']

def read_datetime(arg):
    for dtf in DATE_TIME_FORMATS:
        try:
            return datetime.datetime.strptime(arg, dtf)
        except ValueError:
            pass
    raise ValueError('{0} is not a valid date'.format(arg))

class Filter:
    def __init__(self, server_dir):
        self._exclude_nodes = []
        self._start = None
        self._end = None
        self._default = False

        f = server_dir / 'wombat.filter'
        if not f.exists():
            f = server_dir / 'inspector.filter'
        if f.exists():
            with open(str(f)) as fd:
                print('Found filter file ' + str(f))
                for line in fd:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    cmd, _, arg = line.partition(' ')
                    cmd = cmd.strip().lower()
                    arg = arg.strip()
                    if cmd == 'exclude_node':
                        self._exclude_nodes.append(arg)
                    elif cmd == 'start_date':
                        self._start = read_datetime(arg)
                    elif cmd == 'end_date':
                        self._end = read_datetime(arg)
                    else:
                        raise ValueError('Unknown filter: {}'.format(cmd))
                    # We have one command, so the filter default becomes
                    # true (i.e. process the file unless it falls foul of a
                    # filter rule). With no filter file, or an empty filter
                    # file, the filter default is to filter everything
                    # (i.e. don't process the file).
                    self._default = True
            if self._start and self._end and (self._start >= self.end):
                raise ValueError('{}: Filter end time must be after start time.'.format(str(f)))

    @property
    def start(self):
        return self._start

    @property
    def end(self):
        return self._end

    @property
    def default(self):
        return self._default

    @property
    def exclude_nodes(self):
        return self._exclude_nodes

server_filters = {}

def valid_date_type(arg):
    try:
        return read_datetime(arg)
    except ValueError:
        raise argparse.ArgumentTypeError('Date {0} not valid. Expected format YYYY-MM-DD.'.format(arg))

def link(file_path, target_path):
    """Link file to the target name.

       Ensure that the target directory exists. If target file already exists,
       log warning and return False.
    """
    if target_path.exists():
        logging.warning('link target {} exists'.format(str(target_path)))
        return False
    target_path.parent.mkdir(parents=True, exist_ok=True)
    os.link(str(file_path), str(target_path))
    return True

def files_to_process(path, dir_pattern, file_pattern, from_date=None, to_date=None):
    """Generate list of files in processing order.

       Files matching file_pattern are selected from directories
       under path matching dir_pattern. If from_date is given,
       the file date must be >= from_date. If to_date is given,
       the file date must be < to_date.

       The directory structure is path/<service>/<hostname>/<dir>/<file>.

       For each server we encounter, ensure its filters are loaded.

       To prevent files from a single host blocking timely processing
       of less busy hosts, take one file from each directory at a time."""
    nodefiles = {}
    for dir in pathlib.Path(path).glob(dir_pattern):
        if dir.is_dir():
            node = wc.WombatPath(dir).node
            nodefiles[node] = []
            for f in dir.glob(file_pattern):
                fp = wc.WombatPath(f)
                if fp.server not in server_filters:
                    server_filters[fp.server] = Filter(fp.serverDirPath)
                if from_date or to_date:
                    if from_date and fp.datetime() < from_date:
                        continue
                    if to_date and fp.datetime() >= to_date:
                        continue
                nodefiles[node].append(str(f))
    # Put node files in reverse path order - so in reverse date order,
    # most recent first.
    for node in nodefiles:
        nodefiles[node].sort(reverse=True)
    more = True
    while more:
        more = False
        for node in nodefiles:
            if len(nodefiles[node]) > 0:
                yield nodefiles[node].pop(0)
                more = True

def generate_pcap(wombat_file_path):
    filt = server_filters[wombat_file_path.server]
    if filt.start or filt.end:
        dt = wombat_file_path.datetime()
        if filt.start and dt < filt.start:
            return False
        if filt.end and dt >= filt.end:
            return False
    if wombat_file_path.node in filt.exclude_nodes:
        return False
    return filt.default

def process_incoming(writer, path, dir_pattern, file_pattern):
    """Process incoming jobs.

       Run over C-DNS in */incoming and:

       1. Link to incoming/pending and submit convert to TSV job.
       2. If required, link to pcap/pending and submit convert PCAP job.
       3. Move file from incoming to cbor.
    """
    for f in files_to_process(path, dir_pattern, file_pattern):
        fp = wc.WombatPath(f)
        tp = fp.incomingPendingFilePath
        if link(fp.incomingFilePath, tp):
            writer.add('cdns-to-tsv', tp)

        if generate_pcap(fp):
            tp = fp.pcapPendingFilePath
            if link(fp.incomingFilePath, tp):
                writer.add('cdns-to-pcap', tp)

        cp = fp.cdnsFilePath
        cp.parent.mkdir(parents=True, exist_ok=True)
        fp.incomingFilePath.rename(cp)

def process_reload(writer, path, dir_pattern, file_pattern, from_date, to_date):
    """Process file reloads.

       Run over C-DNS in */cbor and:

       1. Link to cbor/pending and submit low priority convert to TSV job.
    """
    for f in files_to_process(path, dir_pattern, file_pattern, from_date, to_date):
        fp = wc.WombatPath(f)
        tp = fp.cdnsPendingFilePath
        if link(fp.cdnsFilePath, tp):
            writer('cdns-to-tsv', tp, low=True)

def process_pending(writer, path,
                    incoming_dir_pattern, reload_dir_pattern, pcap_dir_pattern,
                    cdns_file_pattern, tsv_file_pattern):
    """Refill queue from pending directories."""
    for f in files_to_process(path, incoming_dir_pattern + '/' + wc.PENDING_DIR, cdns_file_pattern):
        writer.add('cdns-to-tsv', f)

    for f in files_to_process(path, reload_dir_pattern + '/' + wc.PENDING_DIR, cdns_file_pattern):
        writer.add('cdns-to-tsv', f, low=True)

    for f in files_to_process(path, incoming_dir_pattern + '/' + wc.PENDING_DIR, tsv_file_pattern):
        writer.add('import-tsv', f)

    for f in files_to_process(path, pcap_dir_pattern + '/' + wc.PENDING_DIR, cdns_file_pattern):
        writer.add('cdns-to-pcap', f)

def main():
    parser = argparse.ArgumentParser(description='check for files and add to processing queue.')
    parser.add_argument('-c', '--config',
                        dest='conf_file', action='store', default=None,
                        help='configuration file location',
                        metavar='CONFIG_FILE')
    parser.add_argument('-s', '--source',
                        dest='source', action='store',
                        choices=['incoming', 'reload', 'pending'],
                        required=True,
                        help='incoming, reload or pending',
                        metavar='SOURCES')
    parser.add_argument('--from',
                        dest='from_date', action='store',
                        type=valid_date_type,
                        default=None,
                        help='don\'t reload data from before this date',
                        metavar='DATE')
    parser.add_argument('--to',
                        dest='to_date', action='store',
                        type=valid_date_type,
                        default=None,
                        help='don\'t reload data from at or after this date',
                        metavar='DATE')

    args = parser.parse_args()
    if args.from_date and args.to_date and (args.from_date >= args.to_date):
        print('Error: To date must be after From date', file=sys.stderr)
        sys.exit(1)

    cfg = wc.getConfigOrExit(args.conf_file)

    try:
        datastore_cfg = cfg['datastore']

        try:
            l = open('/tmp/wombat-import.lock', 'w')
            fcntl.flock(l, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            logging.error('Another import is active.')
            sys.exit(1)

        qcontext = wc.QueueContext(cfg, parser.prog)
        with qcontext.writer() as writer:
            if args.source == 'incoming':
                process_incoming(writer,
                                 datastore_cfg['path'],
                                 datastore_cfg['incoming_dir_pattern'],
                                 datastore_cfg['cdns_file_pattern'])
            elif args.source == 'reload':
                process_reload(writer,
                               datastore_cfg['path'],
                               datastore_cfg['reload_dir_pattern'],
                               datastore_cfg['cdns_file_pattern'],
                               args.from_date, args.to_date)
            else:
                process_pending(writer,
                                datastore_cfg['path'],
                                datastore_cfg['incoming_dir_pattern'],
                                datastore_cfg['reload_dir_pattern'],
                                datastore_cfg['pcap_dir_pattern'],
                                datastore_cfg['cdns_file_pattern'],
                                datastore_cfg['tsv_file_pattern'])

        logging.debug('done')
        sys.exit(0)
    except ValueError as ve:
        logging.error(ve)
        print(ve, file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        logging.error('exception {exc} ({args})'.format(
            exc=type(e).__name__,
            args=str(e)))
        sys.exit(1)

if __name__ == "__main__":
    main()
