#!/usr/bin/env python3
#
# Copyright 2018 Internet Corporation for Assigned Names and Numbers.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, you can obtain one at https://mozilla.org/MPL/2.0/.
#
# Developed by Sinodun IT (sinodun.com)
#
# Update the Postgres nodes and attribute databases from nodes.csv.
#
# Usage: wombat-nodes-update <path-to-nodes.csv>
#

import argparse
import csv
import sys

import psycopg2

import wombat.common as wc

def str_to_bool(s):
    return not s.lower() in ("no", "n", "false")

def read_csv(filename):
    with open(filename) as f:
        res = []
        for row in csv.reader(f):
            # Each node record is a tuple:
            # (name, descrip, server, city, country, region, shard_no, current)
            # shard_no and current may be None if not specified.
            server = row[0]
            name = row[1]
            region = row[2]
            country = row[3]
            city = row[4]
            descrip = row[5]
            current = None if len(row) < 8 or not row[7] else str_to_bool(row[7])
            shard_no = None if len(row) < 9 or not row[8] else int(row[8])
            res.append((name, descrip, server, city, country, region, shard_no, current))
    return res

def add_attribute(conn, table, val):
    # Ensure 'val' name is present in table 'table'.
    with conn.cursor() as curs:
        curs.execute('INSERT INTO {} (name) VALUES (%s) ON CONFLICT (name) DO NOTHING'.format(table), (val,))
    conn.commit()

def add_all_attributes(conn, nodes, node_index, table):
    for n in nodes:
        add_attribute(conn, table, n[node_index])

def get_attr_index(cur, table, val):
    cur.execute('SELECT id FROM {} WHERE name = %s'.format(table), (val,))
    return cur.fetchone()[0]

def add_or_update_node(conn, node):
    with conn.cursor() as cur:
        name = node[0]
        descrip = node[1]
        server_id = get_attr_index(cur, 'node_server', node[2])
        city_id = get_attr_index(cur, 'node_city', node[3])
        country_id = get_attr_index(cur, 'node_country', node[4])
        region_id = get_attr_index(cur, 'node_region', node[5])
        shard_no = node[6]
        current = node[7]

        cur.execute("""
INSERT INTO node (name, description, server_id, city_id, country_id, region_id)
VALUES (%s, %s, %s, %s, %s, %s)
        ON CONFLICT (name, server_id) DO UPDATE
        SET description = %s,
            server_id = %s,
            city_id = %s,
            country_id = %s,
            region_id = %s;""",
                    (name, descrip, server_id, city_id, country_id, region_id,
                     descrip, server_id, city_id, country_id, region_id))
        if shard_no is not None:
            cur.execute('UPDATE node SET shard_no = %s WHERE name = %s',
                        (shard_no, name))
        if current is not None:
            cur.execute('UPDATE node SET current = %s WHERE name = %s',
                        ('TRUE' if current else 'FALSE',))
    conn.commit()

def main():
    parser = argparse.ArgumentParser(description='update Postgres schema.')
    parser.add_argument('-c', '--config',
                        dest='conf_file', action='store', default=None,
                        help='configuration file location',
                        metavar='CONFIG_FILE')
    parser.add_argument('nodesfile',
                        help='path to CVS file with node info',
                        metavar='NODEFILE')
    args = parser.parse_args()

    cfg = wc.getConfigOrExit(args.conf_file)

    conn = None

    try:
        pgcfg = cfg['postgres']
        conn = psycopg2.connect(dbname=pgcfg['database'],
                                user=pgcfg['user'],
                                password=pgcfg['password'])

        nodes = read_csv(args.nodesfile)
        add_all_attributes(conn, nodes, 2, 'node_server')
        add_all_attributes(conn, nodes, 3, 'node_city')
        add_all_attributes(conn, nodes, 4, 'node_country')
        add_all_attributes(conn, nodes, 5, 'node_region')

        for n in nodes:
            add_or_update_node(conn, n)

        conn.close()
        sys.exit(0)
    except Exception as e:
        if conn is not None:
            conn.rollback()
            conn.close()
        print(e, file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
