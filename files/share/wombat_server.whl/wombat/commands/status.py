#!/usr/bin/env python3
#
# Copyright 2018 Internet Corporation for Assigned Names and Numbers.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, you can obtain one at https://mozilla.org/MPL/2.0/.
#
# Developed by Sinodun IT (sinodun.com)
#
# Get Wombat queue status info

import argparse
import logging
import sys

import wombat.common as wc

def main():
    parser = argparse.ArgumentParser(description='get queue status.')
    parser.add_argument('-c', '--config',
                        dest='conf_file', action='store', default=None,
                        help='configuration file location',
                        metavar='CONFIG_FILE')
    parser.add_argument('-q', '--queue',
                        dest='queue', action='store',
                        choices=['cdns-to-tsv', 'cdns-to-pcap', 'import-tsv'],
                        default=None,
                        help='the queue to use - cdns-to-tsv, cdns-to-pcap or import-tsv',
                        metavar='QUEUE')
    parser.add_argument('items',
                        nargs='*',
                        help='the status item to show (len, running, workers)',
                        metavar='ITEM')

    args = parser.parse_args()

    cfg = wc.getConfigOrExit(args.conf_file)

    try:
        ctx = wc.QueueContext(cfg, parser.prog)
        for q in ctx.status():
            if args.queue:
                if args.queue != q[0]:
                    continue
            else:
                print('{}: '.format(q[0]), end='')
            if args.items:
                first=True
                for item in args.items:
                    try:
                        if first:
                            first=False
                        else:
                            print(',', end='')
                        print(q[['len', 'running', 'workers'].index(item) + 1], end='')
                    except ValueError:
                        print('Unknown item {} - use len, running or workers'.format(item), file=sys.stderr)
                        sys.exit(1)
                print()
            else:
                print('{queue}: {items} queued, {running} running, {workers} workers'.format(
                    queue=q[0], items=q[1], running=q[2], workers=q[3]))
        sys.exit(0)
    except Exception as e:
        logging.error('exception {exc} ({args})'.format(
            exc=type(e).__name__,
            args=str(e)))
    sys.exit(1)

if __name__ == "__main__":
    main()
