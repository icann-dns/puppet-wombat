#!/usr/bin/env python3
#
# Copyright 2018 Internet Corporation for Assigned Names and Numbers.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, you can obtain one at https://mozilla.org/MPL/2.0/.
#
# Developed by Sinodun IT (sinodun.com)
#
# Wait for a job to be available on a job queue. Pass it to the appropriate
# process, and check the return code.
#
# 0 = Success. Delete input file, move on to next job.
# 1 = Failure. Move input file to ..<node>/failed, move on to next job.
# 2 = Transient failure. Re-enter job in queue, sleep for delay period,
#     move on to next job.
# Any other exit code is an infrastructure exit. Log and quit.
#
# All jobs are run by executing a script named <queue-name>.sh.

import argparse
import logging
import os.path
import pathlib
import subprocess
import sys
import time

import wombat.common as wc

def make_job_args(arg, retry_count):
    return arg + '|' + str(retry_count)

def parse_job_args(args):
    arg, sep, retry = args.partition('|')
    if sep:
        try:
            retry_count = int(retry)
        except ValueError:
            retry_count = 0
    else:
        retry_count = 0
    return (arg, retry_count)

def execute_job(qcontext, args, job):
    process = 'wombat-' + job.queue
    arg, retry_count = parse_job_args(job.arg)
    logging.debug('From {queue} run {process} {arg} try {retry}'.format(
        queue=job.queue, process=process, arg=arg, retry=retry_count))

    t_start = time.perf_counter()
    res = subprocess.run([process, arg],
                         stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE)
    if res.returncode == 0:
        logging.debug('{process} {arg} OK, {runtime:0.3f}s'.format(
            process=process, arg=arg,
            runtime=(time.perf_counter() - t_start)))
        p = pathlib.Path(arg)
        p.unlink()
        job.done()
    elif res.returncode == 1 or (res.returncode == 2 and retry_count >= args.max_retries):
        logging.error('{process} {arg} failed, {runtime:0.3f}s'.format(
            process=process, arg=arg,
            runtime=(time.perf_counter() - t_start)))
        logging.error('Stdout: {stdout}'.format(
            stdout=res.stdout.decode().rstrip()))
        logging.error('Stderr: {stderr}'.format(
            stderr=res.stderr.decode().rstrip()))
        p = wc.WombatPath(arg)
        ep = p.errorFilePath
        ep.parent.mkdir(parents=True, exist_ok=True)
        p.path.rename(ep)
        job.failed()
    elif res.returncode == 2:
        logging.error('{process} {arg} transient failure {count}, {runtime:0.3f}s'.format(
            process=process, arg=arg, count=retry_count,
            runtime=(time.perf_counter() - t_start)))
        logging.error('Stdout: {stdout}'.format(
            stdout=res.stdout.decode().rstrip()))
        logging.error('Stderr: {stderr}'.format(
            stderr=res.stderr.decode().rstrip()))
        job.failed()
        with qcontext.writer() as writer:
            writer.add(job.queue, make_job_args(arg, retry_count + 1))
        time.sleep(args.fail_delay)
    else:
        logging.error('Infrastructure error')
        logging.error('Stdout: {stdout}'.format(
            stdout=res.stdout.decode().rstrip()))
        logging.error('Stderr: {stderr}'.format(
            stderr=res.stderr.decode().rstrip()))
        raise OSError('Infrastructure error exit code')

def main():
    parser = argparse.ArgumentParser(description='process Wombat jobs.')
    parser.add_argument('-c', '--config',
                        dest='conf_file', action='store', default=None,
                        help='configuration file location',
                        metavar='CONFIG_FILE')
    parser.add_argument('--fail_delay',
                        dest='fail_delay', action='store', type=int, default=5,
                        help='delay on process failure',
                        metavar='FAILURE_DELAY')
    parser.add_argument('--max_retries',
                        dest='max_retries', action='store', type=int, default=5,
                        help='maximum times to retry a job with a transient failure',
                        metavar='RETRIES')

    args = parser.parse_args()

    cfg = wc.getConfigOrExit(args.conf_file)

    try:
        qcontext = wc.QueueContext(cfg, parser.prog)
        with qcontext.reader() as reader:
            reader.register('cdns-to-tsv')
            reader.register('cdns-to-pcap')
            reader.register('import-tsv')
            while True:
                job = reader.get()
                try:
                    execute_job(qcontext, args, job)
                except OSError as ose:
                    logging.error('execution process error {err}'.format(err=ose))
                    break
    except Exception as e:
        logging.error('exception {exc} ({args})'.format(
            exc=type(e).__name__,
            args=str(e)))
    except KeyboardInterrupt:
        pass
    sys.exit(1)

if __name__ == "__main__":
    main()
