#!/usr/bin/env python3
#
# Copyright 2018 Internet Corporation for Assigned Names and Numbers.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, you can obtain one at https://mozilla.org/MPL/2.0/.
#
# Developed by Sinodun IT (sinodun.com)
#
# Keep the Clickhouse schema up to date. Clickhouse must be accessible
# from the default user. 'clickhouse-client' must be installed.
#
# Usage: wombat-clickhouse-update <ddl-directory>
#

import argparse
import pathlib
import subprocess
import sys

def fatal(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)

def clickhouse_query_can_error(query):
    try:
        return subprocess.run(['clickhouse-client', '--multiquery'],
                              input=query,
                              stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE,
                              universal_newlines=True,
                              check=True)
    except FileNotFoundError:
        fatal('clickhouse-client not present.')

def clickhouse_query(query):
    try:
        return clickhouse_query_can_error(query)
    except subprocess.CalledProcessError as cpe:
        fatal(cpe.stderr)

def clickhouse_query_file(filepath):
    with filepath.open() as f:
        sql = f.read()
    clickhouse_query(sql)


def createdb(ddlpath):
    schema = pathlib.Path(ddlpath) / 'schema.sql'
    clickhouse_query_file(schema)

def getdbversion(ddlpath):
    try:
        res = clickhouse_query_can_error('select max(version) from wombat.ddl_history;')
        return int(res.stdout)
    except subprocess.CalledProcessError as cpe:
        createdb(ddlpath)
        return 0

def applyDDL(version, ddlpath):
    # build list of ddl's
    for ddl in sorted(pathlib.Path(ddlpath).glob('[0-9]*.sql')):
        if int(ddl.stem) > version:
            clickhouse_query_file(ddl)
            clickhouse_query('INSERT INTO wombat.ddl_history VALUES ({}, now());'.format(int(ddl.stem)))
            print('Applied {}.'.format(ddl))
        else:
            print('Skipping {}, already applied.'.format(ddl))

def main():
    parser = argparse.ArgumentParser(description='update Clickhouse schema.')
    parser.add_argument('ddlpath',
                        help='path to directory with DDL files',
                        metavar='DDLPATH')
    args = parser.parse_args()
    applyDDL(getdbversion(args.ddlpath), args.ddlpath)

if __name__ == "__main__":
    main()
