#!/usr/bin/env python3
#
# Copyright 2018 Internet Corporation for Assigned Names and Numbers.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, you can obtain one at https://mozilla.org/MPL/2.0/.
#
# Developed by Sinodun IT (sinodun.com)
#
# Keep the Postgres schema up to date. The Postgres user 'wombat' and
# database 'wombat' must have already been created using the script
# wombat-postgres-create.
#
# Usage: wombat-postgres-update <ddl-directory>
#

import argparse
import datetime
import pathlib
import sys

import psycopg2

import wombat.common as wc

def fatal(msg, conn, cur):
    # Roll back any changes
    if conn is not None:
        conn.rollback()
    # Close communication with the database
    if cur is not None:
        cur.close()
    if conn is not None:
        conn.close()
    print(msg, file=sys.stderr)
    sys.exit(1)

def createdb(conn, ddlpath):
    schema = pathlib.Path(ddlpath) / 'schema.sql'
    with schema.open() as f:
        sql = f.read()
    try:
        with conn.cursor() as curs:
            curs.execute(sql)
            conn.commit()
    except Exception as e:
        conn.rollback()
        raise e

def checkdbversion(cur):
    cur.execute("select max(version) from ddl_history;")
    if cur.rowcount > 1:
        # raise an error
        fatal('Error: Reading from the versions table returned " + cur.rowcount + " rows. Only one was expected.', conn, cur)
    res = cur.fetchone()[0]
    if not res:
        return 0
    return int(res)

def applyDDL(conn, version, ddlpath):
    # build list of ddl's
    for ddl in sorted(pathlib.Path(ddlpath).glob('[0-9]*.sql')):
        if int(ddl.stem) > version:
            with ddl.open() as f:
                sql = f.read()
            try:
                with conn.cursor() as curs:
                    curs.execute(sql)
                    curs.execute('INSERT INTO ddl_history (version, applied) VALUES (%s, %s)', [int(ddl.stem), datetime.datetime.utcnow()])
                conn.commit()
            except Exception as e:
                conn.rollback()
                raise e
            print('Applied {}.'.format(ddl))
        else:
            print('Skipping {}, already applied.'.format(ddl))

def doesschemaexist(cur):
    cur.execute("select exists(select * from information_schema.tables where table_name=%s)", ('ddl_history',))
    return cur.fetchone()[0]

def main():
    parser = argparse.ArgumentParser(description='update Postgres schema.')
    parser.add_argument('-c', '--config',
                        dest='conf_file', action='store', default=None,
                        help='configuration file location',
                        metavar='CONFIG_FILE')
    parser.add_argument('ddlpath',
                        help='path to directory with DDL files',
                        metavar='DDLPATH')
    args = parser.parse_args()

    cfg = wc.getConfigOrExit(args.conf_file)

    try:
        pgcfg = cfg['postgres']
        conn = psycopg2.connect(dbname=pgcfg['database'],
                                user=pgcfg['user'],
                                password=pgcfg['password'])
    except Exception as e:
        fatal(e, None, None)
    try:
        cur = conn.cursor()
    except psycopg2.Error as e:
        fatal(e, conn, None)
    try:
        if not doesschemaexist(cur):
            createdb(conn, args.ddlpath)
        applyDDL(conn, checkdbversion(cur), args.ddlpath)
        cur.close()
        conn.close()
        sys.exit(0)
    except Exception as e:
        fatal(e, conn, cur)

if __name__ == "__main__":
    main()
