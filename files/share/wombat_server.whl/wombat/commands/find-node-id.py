#!/usr/bin/env python3
#
# Copyright 2018 Internet Corporation for Assigned Names and Numbers.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, you can obtain one at https://mozilla.org/MPL/2.0/.
#
# Developed by Sinodun IT (sinodun.com)
#
# Find the node ID given server and node names.
#
# Usage: wombat-find-node-id <server-name> <node-name>
#

import argparse
import csv
import sys

import psycopg2

import wombat.common as wc

def main():
    parser = argparse.ArgumentParser(description='find node ID from Postgres.')
    parser.add_argument('-c', '--config',
                        dest='conf_file', action='store', default=None,
                        help='configuration file location',
                        metavar='CONFIG_FILE')
    parser.add_argument('servername',
                        help='the server name',
                        metavar='SERVERNAME')
    parser.add_argument('nodename',
                        help='the node name',
                        metavar='NODENAME')
    args = parser.parse_args()

    cfg = wc.getConfigOrExit(args.conf_file)

    conn = None

    try:
        pgcfg = cfg['postgres']
        conn = psycopg2.connect(dbname=pgcfg['database'],
                                user=pgcfg['user'],
                                password=pgcfg['password'])

        with conn.cursor() as cur:
            cur.execute('SELECT node_id FROM node_text WHERE server_name=%s AND name=%s',
                        (args.servername, args.nodename,))
            res = cur.fetchone()

        conn.close()

        if res:
            print(res[0])
            sys.exit(0)
        else:
            sys.exit(1)
    except Exception as e:
        if conn is not None:
            conn.rollback()
            conn.close()
        print(e, file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
