#!/usr/bin/env python3
#
# Copyright 2018 Internet Corporation for Assigned Names and Numbers.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, you can obtain one at https://mozilla.org/MPL/2.0/.
#
# Developed by Sinodun IT (sinodun.com)
#
# A utility to obtain Wombat config for use from non-Python worlds.

import argparse
import os.path
import random
import sys

import wombat.common as wc

def main():
    parser = argparse.ArgumentParser(description='get Wombat configuration value.')
    parser.add_argument('-c', '--config',
                        dest='conf_file', action='store', default=None,
                        help='configuration file location',
                        metavar='CONFIG_FILE')
    parser.add_argument('-r', '--random',
                        dest='random', action='store_true',
                        help='pick random entry from command separated list')
    parser.add_argument('cfg', nargs='+',
                        help='config key',
                        metavar='KEY')

    args = parser.parse_args()

    cfg = wc.getConfigOrExit(args.conf_file)

    try:
        for c in args.cfg:
            cfg = cfg[c]
    except KeyError:
        sys.exit(1)

    if args.random:
        print(random.choice(cfg.split(',')))
    else:
        print(cfg)
    sys.exit(0)

if __name__ == "__main__":
    main()
