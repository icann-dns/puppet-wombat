# Copyright 2018 Internet Corporation for Assigned Names and Numbers.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, you can obtain one at https://mozilla.org/MPL/2.0/.
#
# Developed by Sinodun IT (sinodun.com)

import logging

import gear

class QueueJob:
    def __init__(self, job):
        self._job = job

    @property
    def queue(self):
        return self._job.name.decode()

    @property
    def arg(self):
        return self._job.arguments.decode()

    def failed(self):
        self._job.sendWorkFail()

    def done(self):
        self._job.sendWorkComplete()

class QueueReader:
    def __init__(self, client_id, host, port):
        self._client = gear.Worker(client_id)
        self._host = host
        self._port = port

    def __enter__(self):
        self._client.addServer(self._host, self._port)
        self._client.waitForServer()
        return self

    def __exit__(self, *args):
        self._client.shutdown()

    def register(self, queue):
        self._client.registerFunction(queue)

    def get(self):
        job = QueueJob(self._client.getJob())
        logging.debug('Got {arg} from {queue}'.format(queue=job.queue, arg=job.arg))
        return job

class QueueWriter:
    def __init__(self, client_id, host, port):
        self._client = gear.Client(client_id)
        self._host = host
        self._port = port

    def __enter__(self):
        self._client.addServer(self._host, self._port)
        self._client.waitForServer()
        return self

    def __exit__(self, *args):
        self._client.shutdown()

    def add(self, queue, arg, low=False):
        logging.debug('Add {arg} to {queue}{low}'.format(queue=queue, arg=arg, low=' (low priority)' if low else ''))
        self._client.submitJob(gear.Job(queue, str(arg).encode()),
                               background=True,
                               precedence=gear.PRECEDENCE_LOW if low else gear.PRECEDENCE_NORMAL)

    def status(self):
        req = gear.StatusAdminRequest()
        self._client.getConnection().sendAdminRequest(req)
        res = []
        for l in req.response.decode().split('\n'):
            if l == '.':
                break
            queue, jobs, running, workers = l.split('\t')
            res.append((queue, int(jobs), int(running), int(workers)))
        return res

    def version(self):
        req = gear.VersionAdminRequest()
        self._client.getConnection().sendAdminRequest(req)
        return req.response.decode()

class QueueContext:
    def __init__(self, config, client_id):
        gearman_cfg = config['gearman']
        self._host = gearman_cfg['host']
        self._port = gearman_cfg['port']
        self._client_id = client_id

    def reader(self):
        return QueueReader(self._client_id, self._host, self._port)

    def writer(self):
        return QueueWriter(self._client_id, self._host, self._port)

    def status(self):
        with self.writer() as writer:
            return writer.status()

    def version(self):
        with self.writer() as writer:
            return writer.version()
