# Copyright 2018 Internet Corporation for Assigned Names and Numbers.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, you can obtain one at https://mozilla.org/MPL/2.0/.
#
# Developed by Sinodun IT (sinodun.com)

import configparser
import logging.config
import os.path
import sys

_defaults = {
    'gearman': {
        'host': 'localhost',
        'port': 4730
    },
    'datastore': {
        'path': '/opt/volume1/cbor/',
        'incoming_dir_pattern': '*/*/incoming',
        'reload_dir_pattern': '*/*/cbor',
        'pcap_dir_pattern': '*/*/pcap',
        'cdns_file_pattern': '*.cbor.xz',
        'tsv_file_pattern': '*.tsv*'
    },
    'pcap': {
        'compress': 'Y',
        'query-only': ''
    },
    'postgres': {
        'connection': 'postgresql://%(user)s:%(password)s@%(host)s/%(database)s',
        'database': 'wombat',
        'user': 'wombat',
        'password': 'wombat',
        'host': 'iad.datastore.dns.icann.org'
    },
    'clickhouse': {
        'servers': 'iad01.wombat.dns.icann.org,' \
                   'iad02.wombat.dns.icann.org,' \
                   'iad03.wombat.dns.icann.org,' \
                   'iad04.wombat.dns.icann.org,',
        'database': 'wombat',
        'querytable': 'QueryResponse',
        'shard1table': 'QueryResponseShard01',
        'shard2table': 'QueryResponseShard02',
        'shard3table': 'QueryResponseShard03',
        'shard4table': 'QueryResponseShard04'
    },
    'loggers': {
        'keys': 'root'
    },
    'logger_root': {
        'level': 'INFO',
        'handlers': 'syslog'
    },
    'handlers': {
        'keys': 'stream,syslog'
    },
    'handler_stream': {
        'class': 'StreamHandler',
        'formatter': 'default',
        'level': 'NOTSET',
        'args': '(sys.stdout,)'
    },
    'handler_syslog': {
        'class': 'handlers.SysLogHandler',
        'formatter': 'syslog',
        'level': 'NOTSET',
        'args': '("/dev/log",)'
    },
    'formatters': {
        'keys': 'default,syslog'
    },
    'formatter_default': {
        'format': '%(asctime)s: %(name)s - %(levelname)s - %(message)s'
    },
    'formatter_syslog': {
        'format': 'APPNAME - %(name)s - %(levelname)s - %(message)s'
    }
}

class Config(configparser.ConfigParser):
    def __init__(self, configfile=None):
        super().__init__()
        self.read_dict(_defaults)
        if configfile:
            self.read_file(open(configfile))
        else:
            self.read([os.path.expanduser('~/.wombat.cfg'),
                     '/etc/wombat/wombat.cfg'])

        app_name = os.path.basename(sys.argv[0])
        for f in self['formatters']['keys'].split(','):
            f_key = 'formatter_' + f
            val = self.get(f_key, 'format', raw=True)
            self.set(f_key, 'format', val.replace('APPNAME', app_name))

        logging.config.fileConfig(self)

def getConfigOrExit(conf_file):
    try:
        return Config(conf_file)
    except OSError as err:
        print(err, file=sys.stderr)
        sys.exit(1)
