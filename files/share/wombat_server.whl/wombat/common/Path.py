# Copyright 2018 Internet Corporation for Assigned Names and Numbers.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, you can obtain one at https://mozilla.org/MPL/2.0/.
#
# Developed by Sinodun IT (sinodun.com)

import datetime
import os.path
import pathlib

from wombat.common.Config import Config

INCOMING_DIR = 'incoming'
CDNS_DIR = 'cbor'
PCAP_DIR = 'pcap'
PENDING_DIR = 'pending'
ERROR_DIR = 'error'

_KNOWN_DIRS = [ INCOMING_DIR, CDNS_DIR, PCAP_DIR, ERROR_DIR ]

class UnknownDirError(Exception):
    """Exception raised when an unknown directory is found in a Wombat path."""
    def __init__(self, dir):
        super().__init__("Unknown Wombat directory {}".format(dir))

class NoFileError(Exception):
    """Exception raised when asked for a file but none given."""
    def __init__(self):
        super().__init__("No file.")

class WombatPath:
    def __init__(self, path):
        self._path = p = pathlib.Path(path)
        if p.is_dir():
            self._filename = None
        else:
            self._filename = p.name
            p = p.parent
        if p.name == PENDING_DIR:
            p = p.parent
        if p.name not in _KNOWN_DIRS:
            raise UnknownDirError(p.name)
        p = p.parent
        self._node = p.name
        p = p.parent
        self._server = p.name
        self._base = p.parent

    @property
    def server(self):
        return self._server

    @property
    def node(self):
        return self._node

    @property
    def path(self):
        return self._path

    @property
    def serverDirPath(self):
        return self._base / self._server

    @property
    def incomingDirPath(self):
        return self._base / self._server / self._node / INCOMING_DIR

    @property
    def incomingPendingDirPath(self):
        return self._base / self._server / self._node / INCOMING_DIR / PENDING_DIR

    @property
    def cdnsDirPath(self):
        return self._base / self._server / self._node / CDNS_DIR

    @property
    def cdnsPendingDirPath(self):
        return self._base / self._server / self._node / CDNS_DIR / PENDING_DIR

    @property
    def pcapDirPath(self):
        return self._base / self._server / self._node / PCAP_DIR

    @property
    def pcapPendingDirPath(self):
        return self._base / self._server / self._node / PCAP_DIR / PENDING_DIR

    @property
    def errorDirPath(self):
        return self._base / self._server / self._node / ERROR_DIR

    @property
    def incomingFilePath(self):
        if not self._filename:
            raise NoFileError()
        return self.incomingDirPath / self._filename

    @property
    def incomingPendingFilePath(self):
        if not self._filename:
            raise NoFileError()
        return self.incomingPendingDirPath / self._filename

    @property
    def cdnsFilePath(self):
        if not self._filename:
            raise NoFileError()
        return self.cdnsDirPath / self._filename

    @property
    def cdnsPendingFilePath(self):
        if not self._filename:
            raise NoFileError()
        return self.cdnsPendingDirPath / self._filename

    @property
    def pcapFilePath(self):
        if not self._filename:
            raise NoFileError()
        return self.pcapDirPath / self._filename

    @property
    def pcapPendingFilePath(self):
        if not self._filename:
            raise NoFileError()
        return self.pcapPendingDirPath / self._filename

    @property
    def errorFilePath(self):
        if not self._filename:
            raise NoFileError()
        return self.errorDirPath / self._filename

    def datetime(self):
        """Return a date/time associated with the file.

           If the filename is not a Wombat timestamp, return the
           file last modified time.
        """
        if not self._filename:
            raise NoFileError()
        try:
            return datetime.datetime.strptime(self._filename[0:15], '%Y%m%d-%H%M%S')
        except ValueError:
            return datetime.datetime.utcfromtimestamp(os.path.getmtime(self._path))
